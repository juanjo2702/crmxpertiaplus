<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Message;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ChatController extends Controller
{
    public function index()
    {
        return Inertia::render('Chat/Index', [
            'initialContacts' => $this->getContactsData()
        ]);
    }

    public function contacts()
    {
        return response()->json($this->getContactsData());
    }

    private function getContactsData()
    {
        return Contact::with(['messages' => function ($query) {
            $query->orderBy('created_at', 'desc')->take(1);
        }])
            ->orderByDesc(
                \App\Models\Message::select('created_at')
                    ->whereColumn('contact_id', 'contacts.id')
                    ->orderByDesc('created_at')
                    ->limit(1)
            )
            ->get()
            ->map(function ($contact) {
                $lastMsg = $contact->messages->first();
                return [
                    'id' => $contact->id,
                    'name' => $contact->name ?? $contact->wa_id,
                    'avatar' => $contact->profile_pic,
                    'time' => $lastMsg ? $lastMsg->created_at->toIso8601String() : '',
                    'lastMessage' => $lastMsg ? $lastMsg->body : '',
                    'unread' => 0,
                ];
            });
    }

    public function show(Contact $contact)
    {
        // Return messages for a specific contact
        return response()->json(
            $contact->messages()
                ->orderBy('created_at', 'asc')
                ->get()
        );
    }

    public function store(Request $request, Contact $contact, \App\Services\WhatsAppService $whatsapp)
    {
        $request->validate([
            'message' => 'required|string'
        ]);

        $text = $request->input('message');

        // 1. Send via WhatsApp API
        $response = $whatsapp->sendTextMessage($contact->wa_id, $text);

        if (isset($response['error'])) {
            return response()->json(['error' => 'Failed to send message via Meta'], 500);
        }

        $wamId = $response['messages'][0]['id'] ?? 'temp_' . uniqid();

        // 2. Save to DB
        $message = Message::create([
            'wam_id' => $wamId,
            'contact_id' => $contact->id,
            'type' => 'text',
            'body' => $text,
            'status' => 'sent',
            'direction' => 'outgoing',
            'metadata' => json_encode($response),
        ]);

        return response()->json($message);
    }
}
